import SwiftUI

@main
struct MyApp: App {
    @StateObject private var authManager = AuthManager()

    var body: some Scene {
        WindowGroup {
                LoginView().environmentObject(authManager)
        }
    }
}
