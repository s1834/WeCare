//
//  GradientBackground.swift
//  WeCare
//
//  Created by s1834 on 18/02/25.
//

import SwiftUI

struct GradientBackground: View {
    var body: some View {
        LinearGradient(
            gradient: Gradient(colors: [
                Color(red: 0.96, green: 0.91, blue: 0.79),
                Color(red: 0.92, green: 0.85, blue: 0.75)
            ]),
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .edgesIgnoringSafeArea(.all)
    }
}
