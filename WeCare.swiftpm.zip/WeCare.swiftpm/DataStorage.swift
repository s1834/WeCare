//
//  DataStorage.swift
//  WeCare
//
//  Created by s1834 on 23/02/25.
//

import Foundation

struct DataStorage {
    private static let lastCheckupKey = "lastCheckupDates"
    private static let nextAppointmentKey = "nextAppointmentDates"
    private static let savedReportsKey = "savedReports"
    
    static func getLastCheckupDate(for patient: String) -> String {
        let storedDates = UserDefaults.standard.dictionary(forKey: lastCheckupKey) as? [String: String] ?? [:]
        return storedDates[patient] ?? "Not Available"
    }
    
    static func setLastCheckupDate(for patient: String, date: String) {
        var storedDates = UserDefaults.standard.dictionary(forKey: lastCheckupKey) as? [String: String] ?? [:]
        storedDates[patient] = date
        UserDefaults.standard.setValue(storedDates, forKey: lastCheckupKey)
    }
    
    static func setNextAppointmentDate(for patient: String, date: Date) {
            var storedDates = UserDefaults.standard.dictionary(forKey: nextAppointmentKey) as? [String: TimeInterval] ?? [:]
            
            storedDates[patient] = date.timeIntervalSince1970
            
            UserDefaults.standard.setValue(storedDates, forKey: nextAppointmentKey)
        }
        
        static func getNextAppointmentDate(for patient: String) -> Date? {
            let storedDates = UserDefaults.standard.dictionary(forKey: nextAppointmentKey) as? [String: TimeInterval] ?? [:]
            if let timeInterval = storedDates[patient] {
                return Date(timeIntervalSince1970: timeInterval)
            }
            return nil
        }
    
    static func fetchReports(for selectedPatient: String) -> [URL] {
        guard let savedData = UserDefaults.standard.string(forKey: savedReportsKey),
              let data = savedData.data(using: .utf8) else {
            return uploadSampleReportIfNeeded(for: selectedPatient)
        }

        do {
            let decoded = try JSONDecoder().decode([String: [String]].self, from: data)
            let reportURLs = decoded[selectedPatient]?.compactMap { URL(string: $0) } ?? []

            return reportURLs.isEmpty ? uploadSampleReportIfNeeded(for: selectedPatient) : reportURLs
        } catch {
            print("⚠️⚠️ Failed to fetch reports: \(error.localizedDescription)")
            return uploadSampleReportIfNeeded(for: selectedPatient)
        }
    }

    private static func uploadSampleReportIfNeeded(for patient: String) -> [URL] {
        let fileManager = FileManager.default

        let currentFilePath = URL(fileURLWithPath: #filePath)
        let projectRoot = currentFilePath
            .deletingLastPathComponent()
        
        let resourcesPath = projectRoot.appendingPathComponent("Resources")
        let sampleReportURL = resourcesPath.appendingPathComponent("sample_report.pdf")

        print("📂📂 Looking for sample report at: \(sampleReportURL.path)")

        guard fileManager.fileExists(atPath: sampleReportURL.path) else {
            print("⚠️⚠️ Sample report not found at \(sampleReportURL.path)")
            return []
        }

        var storedReports = [patient: [sampleReportURL.absoluteString]]
        
        if let existingData = UserDefaults.standard.string(forKey: savedReportsKey),
           let existingDict = try? JSONDecoder().decode([String: [String]].self, from: Data(existingData.utf8)) {
            storedReports.merge(existingDict) { (current, _) in current }
        }

        if let encodedData = try? JSONEncoder().encode(storedReports),
           let jsonString = String(data: encodedData, encoding: .utf8) {
            UserDefaults.standard.setValue(jsonString, forKey: savedReportsKey)
        }

        print("✅✅ Sample report added for \(patient) at \(sampleReportURL.path)")
        return [sampleReportURL]
    }
}
