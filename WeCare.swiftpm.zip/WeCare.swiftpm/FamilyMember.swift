import SwiftUI

struct FamilyMember: Identifiable, Codable {
    var id = UUID()
    var name: String
    var email: String
    var relation: String
    var phone: String
}
