//
//  DataModel.swift
//  WeCare
//
//  Created by s1834 on 18/02/25.
//

import Foundation

@MainActor
class UserManager {
    static let shared = UserManager()

    private init() {}

    func saveUser(username: String? = nil, password: String? = nil, role: String, familyMembers: [String]? = nil, reports: [String]? = nil) {
        let existingUsername = UserDefaults.standard.string(forKey: "\(role)_username") ?? ""
        let existingPassword = UserDefaults.standard.string(forKey: "\(role)_password") ?? ""
        
        let newUsername = username ?? existingUsername
        let newPassword = password ?? existingPassword

        UserDefaults.standard.set(newUsername, forKey: "\(role)_username")
        UserDefaults.standard.set(newPassword, forKey: "\(role)_password")
        
        if let familyMembers = familyMembers {
            UserDefaults.standard.set(familyMembers, forKey: "\(role)_familyMembers")
        }

        if let reports = reports {
            UserDefaults.standard.set(reports, forKey: "\(role)_reports")
        }

        print("✅✅ User data saved for role: \(role)")
    }

    func validateUser(username: String, password: String, role: String) -> Bool {
        let savedUsername = UserDefaults.standard.string(forKey: "\(role)_username") ?? ""
        let savedPassword = UserDefaults.standard.string(forKey: "\(role)_password") ?? ""
        return username == savedUsername && password == savedPassword
    }

    func loadUser(role: String) -> (username: String, password: String, familyMembers: [String], reports: [String])? {
        let username = UserDefaults.standard.string(forKey: "\(role)_username")
        let password = UserDefaults.standard.string(forKey: "\(role)_password")
        
        if username == nil || password == nil {
            print("🚨🚨 User not found for role: \(role). Logging out!")
            return nil
        }

        let familyMembers = UserDefaults.standard.array(forKey: "\(role)_familyMembers") as? [String] ?? []
        let reports = UserDefaults.standard.array(forKey: "\(role)_reports") as? [String] ?? []

        print("✅✅ Loaded User: \(username!) | Role: \(role) | Family: \(familyMembers.count) members")
        
        return (username!, password!, familyMembers, reports)
    }
    
    func addFamilyMember(role: String, member: String) {
        guard var userData = loadUser(role: role) else {
            print("⚠️⚠️ Failed to load user data for role: \(role)")
            return
        }

        userData.familyMembers.append(member)
        saveUser(username: userData.username, password: userData.password, role: role, familyMembers: userData.familyMembers, reports: userData.reports)

        print("✅✅ Family member added successfully!")
    }
}

