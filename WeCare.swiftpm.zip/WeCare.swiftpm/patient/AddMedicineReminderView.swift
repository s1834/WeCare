//
//  AddMedicineReminderView.swift
//  WeCare
//
//  Created by s1834 on 23/02/25.
//

import SwiftUI

struct AddMedicineReminderView: View {
    @Binding var medicineReminders: [String]
    @State private var medicineName: String = ""
    @State private var morning: Bool = false
    @State private var afternoon: Bool = false
    @State private var evening: Bool = false
    @State private var night: Bool = false
    @State private var beforeFood: Bool = false
    @State private var afterFood: Bool = false
    
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Medicine Name")) {
                    TextField("Enter Medicine Name", text: $medicineName)
                }
                
                Section(header: Text("Times to Take")) {
                    Toggle("Morning", isOn: $morning)
                    Toggle("Afternoon", isOn: $afternoon)
                    Toggle("Evening", isOn: $evening)
                    Toggle("Night", isOn: $night)
                }
                
                Section(header: Text("Food Timing")) {
                    Toggle("Before Food", isOn: $beforeFood)
                    Toggle("After Food", isOn: $afterFood)
                }
            }
            .navigationTitle("Add Medicine Reminder")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        saveMedicineReminder()
                        dismiss()
                    }
                    .foregroundColor(.blue)
                }
            }
        }
    }
    
    private func saveMedicineReminder() {
        var reminderDetails = "\(medicineName) -"
        var times: [String] = []
        
        if morning { times.append("Morning") }
        if afternoon { times.append("Afternoon") }
        if evening { times.append("Evening") }
        if night { times.append("Night") }
        
        let timeString = times.isEmpty ? "No Specific Time" : times.joined(separator: ", ")
        
        var foodTiming = ""
        if beforeFood { foodTiming += "Before Food" }
        if afterFood {
            foodTiming += beforeFood ? ", After Food" : "After Food"
        }
        
        let fullReminder = "\(medicineName) - \(timeString) (\(foodTiming))"
        
        if !medicineName.isEmpty {
            medicineReminders.append(fullReminder)
            dismiss()
        }
    }
}
