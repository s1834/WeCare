//
//  PatientFamilyView.swift
//  WeCare
//
//  Created by s1834 on 20/02/25.
//

import SwiftUI

struct PatientFamilyView: View {
    @State private var familyMembers: [FamilyMember] = []
    @State private var isAddingFamily = false

    var body: some View {
        VStack {
            Text("Family Members")
                .font(.title)
                .fontWeight(.bold)
                .padding(.top, 20)

            if familyMembers.isEmpty {
                VStack {
                    Image(systemName: "person.3.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100, height: 100)
                        .foregroundColor(.gray.opacity(0.5))
                        .padding(.bottom, 10)
                    
                    Text("No family members added yet.")
                        .foregroundColor(.gray)
                        .font(.subheadline)
                }
                .padding()
            } else {
                ScrollView {
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                        ForEach(familyMembers, id: \.id) { member in
                            VStack {
                                Image(systemName: "person.circle.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 50, height: 50)
                                    .foregroundColor(.blue)
                                
                                Text(member.name)
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                
                                Text(member.relation)
                                    .foregroundColor(.secondary)
                                    .font(.subheadline)
                                
                                Divider()
                                    .background(Color.gray.opacity(0.5))
                                
                                VStack(spacing: 4) {
                                    HStack {
                                        Image(systemName: "envelope.fill")
                                            .foregroundColor(.gray)
                                        Text(member.email)
                                            .font(.footnote)
                                            .foregroundColor(.blue)
                                    }
                                    
                                    HStack {
                                        Image(systemName: "phone.fill")
                                            .foregroundColor(.gray)
                                        Text(member.phone)
                                            .font(.footnote)
                                    }
                                }
                            }
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.white.opacity(0.9))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .shadow(radius: 5)
                        }
                    }
                    .padding()
                }
            }

            Spacer()

            Button(action: { isAddingFamily.toggle() }) {
                HStack {
                    Image(systemName: "plus.circle.fill")
                        .resizable()
                        .frame(width: 25, height: 25)
                    
                    Text("Add Family Member")
                        .fontWeight(.semibold)
                }
                .padding()
                .foregroundColor(.white)
                .background(Color.blue)
                .clipShape(Capsule())
                .shadow(radius: 5)
            }
            .padding(.bottom, 20)
            .sheet(isPresented: $isAddingFamily, onDismiss: saveFamilyMembers) {
                AddFamilyView(familyMembers: $familyMembers)
            }
        }
        .onAppear(perform: loadFamilyMembers)
        .background(Color.clear)

    }

    private func saveFamilyMembers() {
        if let encoded = try? JSONEncoder().encode(familyMembers) {
            UserDefaults.standard.set(encoded, forKey: "savedFamilyMembers")
        }
    }

    private func loadFamilyMembers() {
        if let savedData = UserDefaults.standard.data(forKey: "savedFamilyMembers"),
           let decoded = try? JSONDecoder().decode([FamilyMember].self, from: savedData) {
            familyMembers = decoded
        }
    }
}
