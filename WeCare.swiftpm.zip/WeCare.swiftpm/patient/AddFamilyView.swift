//
//  AddFamilyView.swift
//  WeCare
//
//  Created by s1834 on 20/02/25.
//

import SwiftUI

struct AddFamilyView: View {
    @Binding var familyMembers: [FamilyMember]
    @Environment(\.presentationMode) var presentationMode

    @State private var name = ""
    @State private var email = ""
    @State private var relation = ""
    @State private var phone = ""

    var body: some View {
        VStack {
            Text("Add Family Member")
                .font(.title2)
                .fontWeight(.bold)
                .padding(.top, 20)
            
            Form {
                Section {
                    TextField("Full Name", text: $name)
                        .textInputAutocapitalization(.words)
                        .padding()
                    
                    TextField("Relation", text: $relation)
                        .textInputAutocapitalization(.words)
                        .padding()
                    
                    TextField("Email", text: $email)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.none)
                        .padding()
                    
                    TextField("Phone Number", text: $phone)
                        .keyboardType(.phonePad)
                        .padding()
                }

                Section {
                    Button(action: addFamilyMember) {
                        HStack {
                            Image(systemName: "person.badge.plus.fill")
                            Text("Add Member")
                                .fontWeight(.bold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .foregroundColor(.white)
                        .background(name.isEmpty || relation.isEmpty || email.isEmpty || phone.isEmpty ? Color.gray : Color.green)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                    .disabled(name.isEmpty || relation.isEmpty || email.isEmpty || phone.isEmpty)
                }
            }
            .background(Color(.systemGroupedBackground))
        }
    }

    private func addFamilyMember() {
        let newMember = FamilyMember(name: name, email: email, relation: relation, phone: phone)
        familyMembers.append(newMember)
        presentationMode.wrappedValue.dismiss()
    }
}
