//
//  PatientProfileSheetView.swift
//  WeCare
//
//  Created by s1834 on 20/02/25.
//

import SwiftUI

struct PatientProfileSheetView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var firstName: String = "John"
    @State private var lastName: String = "Doe"
    @State private var dateOfBirth: String = "Not Set"
    @State private var sex: String = "Not Set"
    @State private var bloodType: String = "Not Set"
    @State private var isLoggedOut = false
    @State private var showDatePicker = false
    @State private var showSexPicker = false
    @State private var showBloodTypePicker = false

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button(action: { presentationMode.wrappedValue.dismiss() }) {
                    HStack {
                        Image(systemName: "chevron.left")
                        Text("Back")
                    }
                    .foregroundColor(.blue)
                }
                Spacer()
                Text("Patient")
                    .font(.headline)
                    .bold()
                Spacer()
                Button("Done") { presentationMode.wrappedValue.dismiss() }
                    .foregroundColor(.blue)
            }
            .padding(.horizontal)
            .padding(.top, 20)

            Spacer()

            VStack(spacing: 10) {
                Image(systemName: "person.crop.circle.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 90, height: 90)
                    .foregroundColor(.gray)
                    .clipShape(Circle())
                    .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 2)

                Text("\(firstName) \(lastName)")
                    .font(.title2)
                    .fontWeight(.bold)
            }

            Spacer()

            VStack(spacing: 0) {
                EditableRow(label: "First Name", value: $firstName)
                Divider()
                EditableRow(label: "Last Name", value: $lastName)
                Divider()
                EditableRow(label: "Date of Birth", value: $dateOfBirth, isEditable: true, showChevron: true) {
                    showDatePicker.toggle()
                }
                Divider()
                EditableRow(label: "Sex", value: $sex, isEditable: true, showChevron: true) {
                    showSexPicker.toggle()
                }
                Divider()
                EditableRow(label: "Blood Type", value: $bloodType, isEditable: true, showChevron: true) {
                    showBloodTypePicker.toggle()
                }
            }
            .background(Color.white)
            .cornerRadius(12)
            .padding(.horizontal)

            Button(action: {
                logoutUser()
            }) {
                Text("Logout")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.red.opacity(0.9))
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .font(.system(size: 18, weight: .bold))
            }
            .padding()
            .padding(.top, 10)
        }
        .background(Color.white.edgesIgnoringSafeArea(.all))
        .padding(.bottom)
        .fullScreenCover(isPresented: $isLoggedOut) {
            LoginView()
        }
        .sheet(isPresented: $showDatePicker) {
            DatePickerView(selectedDate: $dateOfBirth)
        }
        .sheet(isPresented: $showSexPicker) {
            PickerView(title: "Select Sex", selection: $sex, options: ["Male", "Female", "Other"])
        }
        .sheet(isPresented: $showBloodTypePicker) {
            PickerView(title: "Select Blood Type", selection: $bloodType, options: ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"])
        }
    }

    func logoutUser() {
        UserDefaults.standard.removeObject(forKey: "currentPatient")
        isLoggedOut = true
    }
}

struct EditableRow: View {
    let label: String
    @Binding var value: String
    var isEditable: Bool = false
    var showChevron: Bool = false
    var onTap: (() -> Void)? = nil

    var body: some View {
        HStack {
            Text(label)
            Spacer()
            if isEditable {
                Button(action: { onTap?() }) {
                    HStack {
                        Text(value)
                            .foregroundColor(value == "Not Set" ? .gray : .primary)
                            .opacity(isEditable ? 0.6 : 1)
                        if showChevron {
                            Image(systemName: "chevron.right")
                                .foregroundColor(.gray)
                        }
                    }
                }
            } else {
                TextField("", text: $value)
                    .multilineTextAlignment(.trailing)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
        }
        .padding(.vertical, 10)
    }
}

struct DatePickerView: View {
    @Binding var selectedDate: String
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack {
            DatePicker("Select Date of Birth", selection: Binding(
                get: { dateFormatter.date(from: selectedDate) ?? Date() },
                set: { selectedDate = dateFormatter.string(from: $0) }
            ), displayedComponents: .date)
            .datePickerStyle(WheelDatePickerStyle())

            Button("Done") {
                presentationMode.wrappedValue.dismiss()
            }
            .padding()
        }
        .padding()
    }

    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter
    }
}

struct PickerView: View {
    var title: String
    @Binding var selection: String
    var options: [String]
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack {
            Text(title)
                .font(.headline)
                .padding()
            Picker(selection: $selection, label: Text("")) {
                ForEach(options, id: \.self) { option in
                    Text(option).tag(option)
                }
            }
            .pickerStyle(WheelPickerStyle())

            Button("Done") {
                presentationMode.wrappedValue.dismiss()
            }
            .padding()
        }
    }
}
