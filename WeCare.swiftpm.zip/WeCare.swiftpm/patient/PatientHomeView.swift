//
//  PatientHomeView.swift
//  WeCare
//
//  Created by s1834 on 20/02/25.
//

import SwiftUI
import PDFKit

struct PatientHomeView: View {
    @State private var medicineReminders: [String] = []
    @State private var waterIntake: Int = 0
    @State private var showMedicineSheet = false
    @State private var showWaterAlert = false
    @State private var showReportSheet = false
    @State private var pdfURL: URL?
    
    @State private var uploadedReports: [String: [URL]] = [:]
    @State private var showPDFViewer = false

    let patientName = "John Doe"
    let totalWaterGlasses = 8

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Last Checkup Date: " + Constants.getLastCheckupDate(for: patientName))
                let nextAppointmentDate = DataStorage.getNextAppointmentDate(for: patientName)
                Text("Next Appointment: \(nextAppointmentDate != nil ? formatDate(nextAppointmentDate!) : "No upcoming appointment")")
                    .font(.headline)
                    .foregroundColor(.black)
                Button(action: {
                    fetchReports(for: patientName)
                    showReportSheet.toggle()
                }) {
                    Text("View Past Reports")
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                Divider()

                HStack {
                    Text("Medicine Reminders")
                        .font(.title2)
                        .fontWeight(.bold)
                        .padding(.top)

                    Spacer()

                    Button(action: { showMedicineSheet = true }) {
                        Image(systemName: "plus.circle.fill")
                            .resizable()
                            .frame(width: 40, height: 40)
                            .foregroundColor(.blue)
                    }
                }
                .padding(.horizontal)

                if medicineReminders.isEmpty {
                    VStack {
                        Text("No medicines added.")
                            .foregroundColor(.gray)
                            .font(.subheadline)
                            .padding()
                    }
                } else {
                    ScrollView {
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                            ForEach(medicineReminders, id: \.self) { medicine in
                                VStack(spacing: 10) {
                                    let parts = medicine.split(separator: "-").map { $0.trimmingCharacters(in: .whitespaces) }

                                    let name = parts.first ?? "Unknown"
                                    let timeAndFood = parts.count > 1 ? parts[1] : ""

                                    let timeAndFoodParts = timeAndFood.split(separator: "(").map { $0.trimmingCharacters(in: .whitespaces) }
                                    let time = timeAndFoodParts.first ?? "Time not set"
                                    let foodInfo = timeAndFoodParts.count > 1 ? timeAndFoodParts[1].replacingOccurrences(of: ")", with: "") : "Food info not set"

                                    Text(name)
                                        .font(.headline)
                                        .fontWeight(.semibold)
                                        .multilineTextAlignment(.center)
                                        .foregroundColor(.primary)

                                    Text("⏰ \(time)")
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)

                                    if foodInfo != "Food info not set" {
                                        Text("🍽 \(foodInfo)")
                                            .font(.footnote)
                                            .foregroundColor(.gray)
                                    }

                                    Spacer()

                                    Divider()
                                        .background(Color.gray.opacity(0.3))

                                    Button(action: { deleteMedicine(medicine) }) {
                                        Image(systemName: "trash.fill")
                                            .resizable()
                                            .frame(width: 20, height: 20)
                                            .foregroundColor(.red)
                                    }
                                }
                                .padding()
                                .frame(maxWidth: .infinity, minHeight: 180)
                                .background(Color.white.opacity(0.9))
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                                .shadow(radius: 5)
                            }
                        }
                        .padding()
                    }
                }

                Divider()
                
                Text("Water Intake")
                    .font(.headline)
                    .padding(.top)

                VStack {
                    HStack {
                        ForEach(0..<totalWaterGlasses, id: \.self) { index in
                            Image(systemName: index < waterIntake ? "drop.fill" : "drop")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 30, height: 30)
                                .foregroundColor(index < waterIntake ? .blue : .gray.opacity(0.5))
                        }
                    }
                    .padding()

                    Text("\(waterIntake) / \(totalWaterGlasses) glasses")
                        .font(.subheadline)
                        .fontWeight(.bold)

                    HStack {
                        Button(action: {
                            if waterIntake < totalWaterGlasses {
                                waterIntake += 1
                                saveWaterIntake()
                                if waterIntake == totalWaterGlasses { showWaterAlert = true }
                            }
                        }) {
                            Label("Drink", systemImage: "plus")
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }

                        Button(action: {
                            if waterIntake > 0 {
                                waterIntake -= 1
                                saveWaterIntake()
                            }
                        }) {
                            Label("Undo", systemImage: "minus")
                                .padding()
                                .background(Color.red)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                    }
                }
            }
            .padding()
        }
        .onAppear {
            DispatchQueue.main.async {
                loadMedicineReminders()
                loadWaterIntake()
            }
        }
        .onChange(of: medicineReminders) { _ in
            saveMedicineReminders()
        }
        .alert(isPresented: $showWaterAlert) {
            Alert(title: Text("Goal Reached!"), message: Text("You've reached your daily water intake goal!"), dismissButton: .default(Text("OK")))
        }
        .sheet(isPresented: $showMedicineSheet, onDismiss: {
            DispatchQueue.main.async {
                loadMedicineReminders()
            }
        }) {
            AddMedicineReminderView(medicineReminders: $medicineReminders)
        }
        .sheet(isPresented: $showPDFViewer) {
            if let url = pdfURL {
                PDFViewer(url: url)
            } else {
                Text("No PDF available")
            }
        }
        .sheet(isPresented: $showReportSheet) {
            if let reports = uploadedReports[patientName], !reports.isEmpty {
                ReportListView(
                    patient: patientName,
                    uploadedReports: uploadedReports,
                    pdfURL: $pdfURL,
                    showPDFViewer: $showPDFViewer
                )
            }
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
    
    private func fetchReports(for patient: String) {
        DispatchQueue.main.async {
            self.uploadedReports[patient] = DataStorage.fetchReports(for: patient)
            print("✅✅ Fetched \(self.uploadedReports[patient]?.count ?? 0) reports for \(patient)")
        }
    }

    func savePDF() {
        let pdfDocument = PDFDocument()
        let pdfData = pdfDocument.dataRepresentation()
        let fileURL = FileManager.default.temporaryDirectory.appendingPathComponent("report.pdf")

        do {
            try pdfData?.write(to: fileURL)
            print("PDF saved successfully at \(fileURL)")
        } catch {
            print("Failed to save PDF: \(error)")
        }
    }

    func sharePDF() {
        let fileURL = FileManager.default.temporaryDirectory.appendingPathComponent("report.pdf")
        let activityViewController = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)

        if let topVC = UIApplication.shared.connectedScenes
            .compactMap({ ($0 as? UIWindowScene)?.windows.first?.rootViewController })
            .last {
            topVC.present(activityViewController, animated: true)
        }
    }

    func saveMedicineReminders() {
        UserDefaults.standard.set(medicineReminders, forKey: "medicineReminders")
        print("Saved Medicine Reminder: \(medicineReminders)")
    }

    private func loadMedicineReminders() {
        DispatchQueue.main.async {
            if let savedReminders = UserDefaults.standard.array(forKey: "medicineReminders") as? [String] {
                self.medicineReminders = savedReminders
                print("Loaded Medicine Reminders: \(self.medicineReminders)")
            } else {
                self.medicineReminders = []
                print("No reminders found in UserDefaults")
            }
        }
    }

    func deleteMedicine(_ medicine: String) {
        if let index = medicineReminders.firstIndex(of: medicine) {
            medicineReminders.remove(at: index)
            saveMedicineReminders()
        }
    }

    func saveWaterIntake() {
        UserDefaults.standard.set(waterIntake, forKey: "waterIntake")
    }

    func loadWaterIntake() {
        waterIntake = UserDefaults.standard.integer(forKey: "waterIntake")
    }
    
}

struct CustomButtonStyle: ButtonStyle {
    var color: Color
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .background(color)
            .foregroundColor(.white)
            .cornerRadius(10)
            .opacity(configuration.isPressed ? 0.7 : 1.0)
    }
}
