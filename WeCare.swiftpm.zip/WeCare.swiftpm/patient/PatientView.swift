//
//  PatientView.swift
//  WeCare
//
//  Created by s1834 on 18/02/25.
//

import SwiftUI
import PDFKit

struct PatientView: View {
    @State private var selectedTab = 0
    @State private var isProfileSheetPresented = false
    @State private var medicineReminders: [String] = []
    @State private var waterIntake: Int = 0
    @State private var familyMembers: [FamilyMember] = []
    
    var body: some View {
        NavigationView {
            ZStack {
                GradientBackground()
                
                VStack {
                    HStack {
                        VStack(alignment: .leading) {
                            Text("WeCare")
                                .font(.system(size: 44, weight: .bold, design: .rounded))
                                .foregroundStyle(
                                    LinearGradient(
                                        gradient: Gradient(colors: [.blue, .green]),
                                        startPoint: .leading,
                                        endPoint: .trailing
                                    )
                                )
                                .shadow(radius: 5)
                        }
                        Spacer()
                        Button(action: { isProfileSheetPresented.toggle() }) {
                            Image(systemName: "person.circle.fill")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .foregroundColor(.black)
                        }
                    }
                    .padding()
                    
                    Spacer()
                    if selectedTab == 0 {
                        PatientHomeView()
                    } else if selectedTab == 1 {
                        PatientFamilyView()
                    } else {
                        PatientBookingView()
                    }
                    Spacer()
                    
                    HStack {
                        TabBarItem(title: "Home", icon: "house", selectedTab: $selectedTab, index: 0)
                        TabBarItem(title: "Family", icon: "person.3.fill", selectedTab: $selectedTab, index: 1)
                        TabBarItem(title: "Book", icon: "calendar.badge.plus", selectedTab: $selectedTab, index: 2)
                    }
                    .frame(height: 60)
                    .background(Color.white.opacity(0.9))
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .shadow(radius: 5)
                }
                .padding()
            }
            .sheet(isPresented: $isProfileSheetPresented) {
                PatientProfileSheetView()
            }
        }
        .navigationBarBackButtonHidden(true) 
    }
}
