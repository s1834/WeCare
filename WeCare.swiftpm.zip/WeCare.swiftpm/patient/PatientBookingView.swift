//
//  PatientBookingView.swift
//  WeCare
//
//  Created by s1834 on 20/02/25.
//

import SwiftUI

struct PatientBookingView: View {
    @State private var selectedPatient: String = "John Doe"
    @State private var appointmentDate: String = ""

    var body: some View {
        VStack {
            BookingOptionsView(
                selectedPatient: $selectedPatient,
                appointmentDate: $appointmentDate
            )
        }
        .padding()
        .onAppear {
            loadCurrentPatient()
        }
    }
    
    private func loadCurrentPatient() {
        if let currentPatient = UserDefaults.standard.string(forKey: "currentPatient") {
            selectedPatient = currentPatient
        } else {
            selectedPatient = "John Doe"
        }
    }
}

