//
//  Constants.swift
//  WeCare
//
//  Created by s1834 on 18/02/25.
//


import Foundation

struct Constants {
    static let doctorName = "Dr. Derek Shepherd"
    
    static func getLastCheckupDate(for patient: String) -> String {
        let dates = [
            "John Doe": "Jan 10, 2025",
            "Jane Smith": "Feb 5, 2025",
            "Michael Brown": "Feb 15, 2025"
        ]
        return dates[patient] ?? "Not Available"
    }
    
    static func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
}
