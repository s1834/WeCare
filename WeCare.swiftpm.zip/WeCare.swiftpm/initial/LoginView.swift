//
//  LoginView.swift
//  WeCare
//
//  Created by s1834 on 18/02/25.
//

import SwiftUI

struct LoginView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var rememberMe: Bool = false
    @State private var selectedRole: String = "Patient"
    @State private var loginSuccess = false
    @State private var loginErrorMessage = ""
    @State private var navigateToView = false
    @EnvironmentObject var authManager: AuthManager

    let roles = ["Patient", "Family", "Doctor"]

    var body: some View {
        NavigationView {
            ZStack {
                GradientBackground()

                VStack(spacing: 12) {
                    Text("WeCare")
                        .font(.system(size: 64, weight: .bold, design: .rounded))
                        .foregroundStyle(
                            LinearGradient(gradient: Gradient(colors: [.blue, .green]), startPoint: .leading, endPoint: .trailing)
                        )
                        .shadow(radius: 5)
                        .padding(.top, -50)

                    Image(systemName: "ribbon")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 80, height: 80)
                        .foregroundStyle(
                            LinearGradient(
                                gradient: Gradient(colors: [
                                    Color(red: 0.96, green: 0.90, blue: 0.85),
                                    Color(red: 0.88, green: 0.78, blue: 0.70)
                                ]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .shadow(radius: 5)
                        .padding(.top, -50)

                    Text("Login👋👋")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity, alignment: .leading)

                    VStack {
                        Text("Select Role")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundColor(.black)

                        HStack(spacing: 8) {
                            ForEach(roles, id: \.self) { role in
                                Button(action: { selectedRole = role }) {
                                    Text(role)
                                        .padding()
                                        .frame(maxWidth: .infinity)
                                        .background(selectedRole == role ? Color.black.opacity(0.8) : Color.black.opacity(0.3))
                                        .cornerRadius(10)
                                        .foregroundColor(.white)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text("Email address")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundColor(.black)

                        TextField("Email address", text: $email)
                            .padding()
                            .background(Color.white.opacity(0.2))
                            .cornerRadius(8)
                            .foregroundColor(.black)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)

                        Text("Password")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundColor(.black)

                        SecureField("Enter Password", text: $password)
                            .padding()
                            .background(Color.white.opacity(0.2))
                            .cornerRadius(8)
                            .foregroundColor(.black)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    .padding(.horizontal)

                    HStack {
                        Button(action: { rememberMe.toggle() }) {
                            HStack {
                                Image(systemName: rememberMe ? "largecircle.fill.circle" : "circle")
                                    .foregroundColor(.black)
                                Text("Remember Me")
                                    .foregroundColor(.black)
                                    .font(.subheadline)
                                    .fontWeight(.semibold)
                            }
                        }
                        Spacer()
                    }
                    .padding(.horizontal)

                    Button(action: login) {
                        Text("Log in")
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.black)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                    }
                    .padding(.horizontal)

                    if loginSuccess {
                        NavigationLink(destination: destinationView(), isActive: $navigateToView) {
                            EmptyView()
                        }
                        .hidden()
                    } else if !loginErrorMessage.isEmpty {
                        Text(loginErrorMessage)
                            .foregroundColor(.red)
                            .padding(.top, 10)
                            .transition(.slide)
                            .animation(.easeIn)
                    }

                    HStack {
                        Text("Don’t have an account?")
                            .foregroundColor(.black)

                        Button(action: {}) {
                            Text("Sign up")
                                .fontWeight(.bold)
                                .foregroundColor(.black)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .center)
                }
                .padding()
            }
            .navigationBarHidden(true)
        }
    }

    func login() {
        loginErrorMessage = ""

        let rolePrefix = selectedRole.lowercased()
        let isValid = UserManager.shared.validateUser(username: email, password: password, role: rolePrefix)

        if isValid {
            UserDefaults.standard.set(email, forKey: "userEmail")
            UserDefaults.standard.set(password, forKey: "userPassword")
            authManager.isLoggedIn = true
            loginSuccess = true
            navigateToView = true
        } else {
            loginErrorMessage = "Invalid credentials. Please try again."
        }
    }

    @ViewBuilder
    func destinationView() -> some View {
        switch selectedRole {
        case "Patient":
            PatientView()
        case "Family":
            FamilyView()
        case "Doctor":
            DoctorView()
        default:
            Text("Unknown role")
        }
    }
}
