//
//  AuthManager.swift
//  WeCare
//
//  Created by s1834 on 19/02/25.
//

import SwiftUI

class AuthManager: ObservableObject {
    @Published var isLoggedIn: Bool = UserDefaults.standard.string(forKey: "userEmail") != nil

    func logout() {
        UserDefaults.standard.removeObject(forKey: "userEmail")
        UserDefaults.standard.removeObject(forKey: "userPassword")
        
        isLoggedIn = false
    }
}
