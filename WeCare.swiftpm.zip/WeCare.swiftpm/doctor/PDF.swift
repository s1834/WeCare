//
//  PDF.swift
//  WeCare
//
//  Created by s1834 on 20/02/25.
//

import SwiftUI
import PDFKit

struct PDFViewer: View {
    var url: URL

    var body: some View {
        PDFKitView(url: url)
            .edgesIgnoringSafeArea(.all)
    }
}

struct PDFKitView: UIViewRepresentable {
    var url: URL

    func makeUIView(context: Context) -> PDFView {
        let pdfView = PDFView()
        
        if FileManager.default.fileExists(atPath: url.path) {
            pdfView.document = PDFDocument(url: url)
            print("✅✅ Loaded PDF from: \(url.path)")
        } else {
            print("❌❌ File does not exist: \(url.path)")
        }

        pdfView.autoScales = true
        return pdfView
    }

    func updateUIView(_ uiView: PDFView, context: Context) {
        if FileManager.default.fileExists(atPath: url.path) {
            uiView.document = PDFDocument(url: url)
        }
    }
}

