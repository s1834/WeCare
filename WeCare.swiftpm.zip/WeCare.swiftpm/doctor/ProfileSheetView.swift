//
//  ProfileSheetView.swift
//  WeCare
//
//  Created by s1834 on 20/02/25.
//

import SwiftUI

struct ProfileSheetView: View {
    @Environment(\.dismiss) var dismiss
    @Binding var isUserLoggedIn: Bool
    @State private var showLoginView = false
    @State private var age: String = "55"
    @State private var specialization: String = "Neurologist"
    @State private var experience: String = "20 years"
    @State private var hospital: String = "Seattle Grace Hospital"
    @State private var contactNumber: String = "+1 123-456-7890"
    @State private var email: String = "derek.shepherd@hospital.com"
    @State private var availability: String = "Mon - Fri, 9 AM - 5 PM"
    @State private var qualifications: String = "MD, Neurosurgery"
    @State private var languages: String = "English, Spanish"
    @State private var consultationFee: String = "$100 per visit"

    var fullName: String {
        Constants.doctorName
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button(action: { dismiss() }) {
                    HStack {
                        Image(systemName: "chevron.left")
                        Text("Back")
                    }
                    .foregroundColor(.blue)
                }
                Spacer()
                Text("Profile")
                    .font(.headline)
                    .bold()
                Spacer()
                Button("Done") { dismiss() }
                    .foregroundColor(.blue)
            }
            .padding(.horizontal)
            .padding(.top, 20)

            Spacer()

            VStack(spacing: 10) {
                Image(systemName: "person.circle.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 90, height: 90)
                    .foregroundColor(.gray)
                    .clipShape(Circle())
                    .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 2)

                Text(fullName)
                    .font(.title2)
                    .fontWeight(.bold)
            }

            Spacer()

            VStack(spacing: 0) {
                EditableRow(label: "Age", value: $age)
                Divider()
                EditableRow(label: "Specialization", value: $specialization)
                Divider()
                EditableRow(label: "Experience", value: $experience)
                Divider()
                EditableRow(label: "Hospital", value: $hospital)
                Divider()
                EditableRow(label: "Qualifications", value: $qualifications)
                Divider()
                EditableRow(label: "Languages", value: $languages)
                Divider()
                EditableRow(label: "Consultation Fee", value: $consultationFee)
                Divider()
                EditableRow(label: "Availability", value: $availability)
                Divider()
                EditableRow(label: "Contact", value: $contactNumber)
                Divider()
                EditableRow(label: "Email", value: $email)
            }
            .background(Color.white)
            .cornerRadius(12)
            .padding(.horizontal)

            Button(action: {
                logoutUser()
            }) {
                Text("Logout")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .font(.system(size: 18, weight: .bold))
            }
            .padding()
            .padding(.top, 10)
        }
        .background(Color.white.edgesIgnoringSafeArea(.all))
        .padding(.bottom)
        .fullScreenCover(isPresented: $showLoginView) {
            LoginView()
        }
    }

    func logoutUser() {
        UserDefaults.standard.set(false, forKey: "isLoggedIn")
        isUserLoggedIn = false
        showLoginView = true
    }
}
