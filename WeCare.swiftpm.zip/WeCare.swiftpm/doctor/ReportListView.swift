//
//  ReportListView.swift
//  WeCare
//
//  Created by s1834 on 23/02/25.
//

import SwiftUI

struct ReportListView: View {
    var patient: String
    var uploadedReports: [String: [URL]]
    @Binding var pdfURL: URL?
    @Binding var showPDFViewer: Bool

    var body: some View {
        NavigationView {
            List(getReports(), id: \.self) { report in
                Button(action: {
                    pdfURL = report
                    showPDFViewer.toggle()
                }) {
                    HStack {
                        Image(systemName: "doc.text")
                            .foregroundColor(.blue)
                        Text(report.lastPathComponent)
                    }
                }
            }
            .navigationTitle("Reports for \(patient)")
        }
    }

    private func getReports() -> [URL] {
        return uploadedReports[patient] ?? []
    }
}
