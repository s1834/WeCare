//
//  DocumentPicker.swift
//  WeCare
//
//  Created by s1834 on 18/02/25.
//

import SwiftUI
import UniformTypeIdentifiers

struct DocumentPicker: UIViewControllerRepresentable {
    @Binding var uploadedReports: [String: [URL]]
    var selectedPatient: String

    @AppStorage("savedReports") private var savedReportsData: String = ""

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        var parent: DocumentPicker

        init(parent: DocumentPicker) {
            self.parent = parent
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            DispatchQueue.main.async {
                guard let url = urls.first else { return }

                let fileManager = FileManager.default
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd_HH-mm-ss"
                let dateString = dateFormatter.string(from: Date())

                let reportFileName = "\(self.parent.selectedPatient)_\(dateString).pdf"
                let destinationURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.appendingPathComponent(reportFileName)

                do {
                    if fileManager.fileExists(atPath: destinationURL.path) {
                        try fileManager.removeItem(at: destinationURL)
                    }
                    try fileManager.copyItem(at: url, to: destinationURL)

                    var reportsDict = self.loadReportsFromStorage()
                    var reports = reportsDict[self.parent.selectedPatient] ?? []
                    reports.append(destinationURL)

                    self.parent.uploadedReports[self.parent.selectedPatient, default: []] = reports
                    
                    reportsDict[self.parent.selectedPatient] = reports
                    self.saveReportsToStorage(reportsDict)

                    print("✅✅ Report saved for \(self.parent.selectedPatient) at \(destinationURL.path)")
                } catch {
                    print("❌❌ Error copying file: \(error.localizedDescription)")
                }
            }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            print("⚠️⚠️ Document picker was cancelled")
        }

        // Helper function to load reports from AppStorage
        private func loadReportsFromStorage() -> [String: [URL]] {
            guard let data = self.parent.savedReportsData.data(using: .utf8) else { return [:] }
            do {
                let decoded = try JSONDecoder().decode([String: [String]].self, from: data)
                return decoded.mapValues { $0.compactMap { URL(string: $0) } }
            } catch {
                print("⚠️⚠️ Failed to load reports from AppStorage: \(error.localizedDescription)")
                return [:]
            }
        }

        // Helper function to save reports to AppStorage
        private func saveReportsToStorage(_ reports: [String: [URL]]) {
            do {
                let encoded = try JSONEncoder().encode(reports.mapValues { $0.map { $0.absoluteString } })
                self.parent.savedReportsData = String(data: encoded, encoding: .utf8) ?? ""
            } catch {
                print("⚠️⚠️ Failed to save reports to AppStorage: \(error.localizedDescription)")
            }
        }
    }

    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.pdf, UTType.image])
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}
}
