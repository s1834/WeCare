//
//  DoctorView.swift
//  WeCare
//
//  Created by s1834 on 18/02/25.
//

import SwiftUI
import UniformTypeIdentifiers

struct DoctorView: View {
    @State private var selectedPatient: String? = nil
    @State private var nextAppointmentDates: [String: Date] = [:]
    @State private var showDatePickerPopup = false
    @State private var tempSelectedDate = Date()
    @State private var isProfileSheetPresented = false
    @State private var patients = ["John Doe", "Jane Smith", "Michael Brown"]
    @State private var uploadedReports: [String: [URL]] = [:]
    @State private var showPDFViewer = false
    @State private var pdfURL: URL?
    @State private var showDocumentPicker = false
    @State private var showReportSheet = false
    @AppStorage("isLoggedIn") private var isUserLoggedIn = false
    @AppStorage("pdfURL") private var storedPDFPath: String = ""
    @EnvironmentObject var authManager: AuthManager
    

    var body: some View {
        NavigationView {
            ZStack {
                GradientBackground()
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        headerView()
                        patientPicker()
                        
                        if let selected = selectedPatient {
                            patientDetailsView(for: selected)
                        }
                    }
                    .padding()
                }
            }
            .navigationBarBackButtonHidden(true)
            .sheet(isPresented: $isProfileSheetPresented) {
                ProfileSheetView(isUserLoggedIn: $isUserLoggedIn)
            }
            .sheet(isPresented: $showPDFViewer) {
                if let url = pdfURL {
                    PDFViewer(url: url)
                } else {
                    Text("No PDF available")
                }
            }
            .sheet(isPresented: $showReportSheet) {
                if let selected = selectedPatient, let reports = uploadedReports[selected], !reports.isEmpty {
                    ReportListView(
                        patient: selected,
                        uploadedReports: uploadedReports,
                        pdfURL: $pdfURL,
                        showPDFViewer: $showPDFViewer
                    )
                }
            }
            .onAppear {
                if !storedPDFPath.isEmpty {
                    pdfURL = URL(fileURLWithPath: storedPDFPath)
                }
            }
            .overlay(datePickerPopup())
        }
    }
    
    @ViewBuilder
    private func headerView() -> some View {
        HStack {
            Text("WeCare")
                .font(.system(size: 44, weight: .bold, design: .rounded))
                .foregroundStyle(
                    LinearGradient(
                        gradient: Gradient(colors: [.blue, .green]),
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .shadow(radius: 5)

            Spacer()

            Button(action: { isProfileSheetPresented.toggle() }) {
                Image(systemName: "person.circle.fill")
                    .resizable()
                    .frame(width: 40, height: 40)
                    .foregroundColor(.black)
            }
        }
        .padding()
    }
    
    @ViewBuilder
    private func patientPicker() -> some View {
        Picker("Select Patient", selection: Binding(
            get: { selectedPatient ?? "" },
            set: { selectedPatient = $0.isEmpty ? nil : $0 }
        )) {
            Text("Select Patient").tag("")
            ForEach(patients, id: \.self) { patient in
                Text(patient).tag(patient)
            }
        }
        .pickerStyle(MenuPickerStyle())
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color.white.opacity(0.8))
        .cornerRadius(10)
    }
    
    private func patientDetailsView(for patient: String) -> some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Last Checkup Date: " + Constants.getLastCheckupDate(for: patient))
                .font(.headline)
                .foregroundColor(.black)

            
            appointmentButton(for: patient)
            reportButtons(for: patient)
        }
    }

    @ViewBuilder
    private func appointmentButton(for patient: String) -> some View {
        let appointmentDate = DataStorage.getNextAppointmentDate(for: patient) ?? Date()
        
        Button(action: { showDatePickerPopup.toggle() }) {
            HStack {
                Text("Set Next Appointment Date").fontWeight(.bold)
                Spacer()
                Text(Constants.formatDate(appointmentDate)).foregroundColor(.white)
            }
            .padding()
            .background(Color.green.opacity(0.8))
            .foregroundColor(.white)
            .cornerRadius(10)
        }
    }
    
    @ViewBuilder
    private func reportButtons(for patient: String) -> some View {
        VStack(spacing: 10) {
            Button(action: { showDocumentPicker.toggle() }) {
                Text("Upload Report")
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.orange)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .sheet(isPresented: $showDocumentPicker) {
                DocumentPicker(uploadedReports: $uploadedReports, selectedPatient: patient)
            }

            Button(action: {
                fetchReports(for: patient)
                showReportSheet.toggle()
            }) {
                Text("View Past Reports")
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
    }
    private func fetchReports(for patient: String) {
        DispatchQueue.main.async {
            self.uploadedReports[patient] = DataStorage.fetchReports(for: patient)
            print("✅✅ Fetched \(self.uploadedReports[patient]?.count ?? 0) reports for \(patient)")
        }
    }
    
    @ViewBuilder
    private func datePickerPopup() -> some View {
        if showDatePickerPopup {
            VStack(spacing: 8) {
                Text("Select Next Appointment Date")
                    .font(.headline)
                    .padding(.top, 12)

                DatePicker("Choose Date", selection: $tempSelectedDate, displayedComponents: .date)
                    .datePickerStyle(GraphicalDatePickerStyle())
                    .labelsHidden()
                    .padding(.horizontal)
                    .cornerRadius(8)

                HStack {
                    Button("Cancel") {
                        showDatePickerPopup = false
                    }
                    .frame(maxWidth: .infinity)
                    .padding(12)
                    .background(Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(10)

                    Button("Confirm") {
                        if let selected = selectedPatient {
                            DataStorage.setNextAppointmentDate(for: selected, date: tempSelectedDate)
                        }
                        showDatePickerPopup = false
                    }
                    .frame(maxWidth: .infinity)
                    .padding(12)
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                }
                .padding(.horizontal, 12)
                .padding(.bottom, 12)
            }
            .frame(width: 320)
            .background(Color.white)
            .cornerRadius(15)
            .shadow(radius: 10)
            .padding()
        }
    }

    private func getLastCheckupDate(for patient: String) -> String {
        let dates = [
            "John Doe": "Jan 10, 2025",
            "Jane Smith": "Feb 5, 2025",
            "Michael Brown": "Feb 15, 2025"
        ]
        return dates[patient] ?? "Not Available"
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
}
