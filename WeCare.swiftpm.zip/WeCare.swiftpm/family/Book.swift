//
//  Book.swift
//  WeCare
//
//  Created by s1834 on 20/02/25.
//

import SwiftUI

struct BookingOptionsView: View {
    @Binding var selectedPatient: String
    @Binding var appointmentDate: String
    @State private var showAppointmentBooking = false
    @State private var showCabBooking = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                if !showAppointmentBooking && !showCabBooking {
                    BookingCard(title: "Book Appointment", icon: "calendar.badge.plus") {
                        showAppointmentBooking = true
                    }
                    BookingCard(title: "Book a Cab", icon: "car.fill") {
                        showCabBooking = true
                    }
                }
                
                if showAppointmentBooking {
                    AppointmentBookingView(
                        selectedPatient: $selectedPatient,
                        appointmentDate: $appointmentDate,
                        onConfirm: {
                            showAppointmentBooking = false
                        }
                    )
                    .padding()
                }
                
                if showCabBooking {
                    CabBookingView(onCancel: {
                        showCabBooking = false
                    })
                    .padding()
                }
            }
            .padding()
        }
    }
}

struct BookingCard: View {
    let title: String
    let icon: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                    .resizable()
                    .frame(width: 30, height: 30)
                    .foregroundColor(.blue)
                Text(title)
                    .font(.title3)
                    .fontWeight(.semibold)
                    .foregroundColor(.black)
                Spacer()
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10)
            .shadow(radius: 3)
        }
    }
}

struct AppointmentBookingView: View {
    @Binding var selectedPatient: String
    @Binding var appointmentDate: String
    @State private var selectedDateTime = Date()
    let onConfirm: () -> Void

    var body: some View {
        VStack(spacing: 20) {
            Text("Book Appointment")
                .font(.title)
                .fontWeight(.bold)

            DatePicker("Select Date & Time", selection: $selectedDateTime, displayedComponents: [.date, .hourAndMinute])
                .datePickerStyle(GraphicalDatePickerStyle())
                .padding()
                .background(Color.white)
                .cornerRadius(10)

            Button(action: {
                let formatter = DateFormatter()
                formatter.dateStyle = .medium
                formatter.timeStyle = .short
                let formattedDateTime = formatter.string(from: selectedDateTime)

                DataStorage.setNextAppointmentDate(for: selectedPatient, date: selectedDateTime)
                appointmentDate = formattedDateTime

                onConfirm()
            }) {
                Text("Confirm Appointment")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
        .padding()
    }
}

struct CabBookingView: View {
    let onCancel: () -> Void
    let cabServices = ["Uber", "Ola", "Rapido"]

    var body: some View {
        VStack(spacing: 20) {
            Text("Book a Cab")
                .font(.title)
                .fontWeight(.bold)

            ForEach(cabServices, id: \.self) { service in
                CabServiceCard(service: service)
            }

            Button(action: onCancel) {
                Text("Cancel")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
        .padding()
    }
}

struct CabServiceCard: View {
    let service: String

    var body: some View {
        HStack {
            Text(service)
                .font(.title3)
                .fontWeight(.semibold)
                .foregroundColor(.black)
            Spacer()
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 3)
    }
}
