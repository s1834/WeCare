//
//  TabBarItem.swift
//  WeCare
//
//  Created by s1834 on 20/02/25.
//

import SwiftUI

struct TabBarItem: View {
    let title: String
    let icon: String
    @Binding var selectedTab: Int
    let index: Int
    
    var body: some View {
        Button(action: { selectedTab = index }) {
            VStack {
                Image(systemName: icon)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 24, height: 24)
                Text(title)
                    .font(.caption)
            }
            .foregroundColor(selectedTab == index ? .blue : .gray)
            .frame(maxWidth: .infinity)
        }
    }
}

