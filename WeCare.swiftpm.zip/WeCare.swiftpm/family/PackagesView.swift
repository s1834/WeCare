import SwiftUI

struct PackagesView: View {
    @Binding var selectedPatient: String
    @State private var currentPackage: Package? = Package(name: "Basic Health Package", benefits: ["2 Doctor Visits per 6 months", "1 Test per month"], price: "$99", duration: "6 Months", startDate: Date(), endDate: Calendar.current.date(byAdding: .month, value: 6, to: Date())!)
    @State private var selectedPackage: Package?
    @State private var showPaymentAlert = false

    var body: some View {
        VStack(spacing: 20) {
            Text("Current Package")
                .font(.title)
                .fontWeight(.bold)
                .padding()

            if !selectedPatient.isEmpty {
                if let currentPackage = currentPackage {
                    CurrentPackageCard(package: currentPackage)
                }

                Text("Available Packages")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .padding()

                LazyVGrid(columns: Array(repeating: GridItem(.flexible(minimum: 150, maximum: 180), spacing: 15), count: 2), spacing: 20) {
                    ForEach(availablePackages, id: \.name) { package in
                        PackageCard(package: package, currentPackage: currentPackage, onSelect: {
                            selectedPackage = package
                            showPaymentAlert = true
                        })
                    }
                }
                .padding(.horizontal)
                .padding(.bottom)
                .alert(isPresented: $showPaymentAlert) {
                    Alert(
                        title: Text("Select Package"),
                        message: Text("Would you like to pay for \(selectedPackage?.name ?? "")?"),
                        primaryButton: .default(Text("Pay Now")) {
                            if let selectedPackage = selectedPackage {
                                currentPackage = selectedPackage
                            }
                        },
                        secondaryButton: .cancel()
                    )
                }
            } else {
                Text("Please select a patient to view package details.")
                    .foregroundColor(.gray)
                    .padding()
            }
        }
        .padding()
    }
}

struct Package {
    var name: String
    var benefits: [String]
    var price: String
    var duration: String
    var startDate: Date
    var endDate: Date
}

struct CurrentPackageCard: View {
    var package: Package

    var body: some View {
        VStack(alignment: .leading) {
            Text("Current Package: \(package.name)")
                .font(.subheadline)
                .fontWeight(.bold)
                .foregroundColor(.black)
                .padding(.bottom, 5)

            Text("Benefits:")
                .font(.footnote)
                .foregroundColor(.black)

            ForEach(package.benefits, id: \.self) { benefit in
                Text("• \(benefit)")
                    .font(.footnote)
            }

            Text("Price: \(package.price) for \(package.duration)")
                .font(.subheadline)
                .fontWeight(.bold)
                .foregroundColor(.blue)
                .padding(.top, 5)

            Text("Valid From: \(formattedDate(package.startDate)) to \(formattedDate(package.endDate))")
                .font(.footnote) // Changed to footnote for a smaller size
                .foregroundColor(.gray)
                .padding(.top, 2)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.2), radius: 4, x: 0, y: 4)
    }
}

struct PackageCard: View {
    var package: Package
    var currentPackage: Package?
    var onSelect: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(package.name)
                .font(.subheadline)
                .fontWeight(.bold)
                .padding(.bottom, 3)

            Text("Benefits:")
                .font(.footnote)
                .fontWeight(.semibold)
                .foregroundColor(.black)

            ForEach(package.benefits, id: \.self) { benefit in
                Text("• \(benefit)")
                    .font(.footnote)
                    .foregroundColor(.gray)
            }

            Spacer()
            
            Text("Price: \(package.price) for \(package.duration)")
                .font(.headline)
                .fontWeight(.bold)
                .foregroundColor(.blue)

            Button(action: {
                if currentPackage?.name == package.name {
                } else {
                    onSelect()
                }
            }) {
                Text(currentPackage?.name == package.name ? "Current Package" : "Select Package")
                    .foregroundColor(.white)
                    .fontWeight(.semibold)
                    .padding(10)
                    .frame(maxWidth: .infinity)
                    .background(currentPackage?.name == package.name ? Color.green : Color.blue)
                    .cornerRadius(10)
            }
            .frame(height: 40)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.2), radius: 4, x: 0, y: 4)
        .overlay(
            RoundedRectangle(cornerRadius: 15)
                .stroke(Color.gray.opacity(0.2), lineWidth: 1)
        )
        .padding(.vertical, 5)
    }
}

let availablePackages: [Package] = [
    Package(name: "Basic Health Package", benefits: ["2 Doctor Visits per 6 months", "1 Test per month"], price: "$99", duration: "6 Months", startDate: Date(), endDate: Calendar.current.date(byAdding: .month, value: 6, to: Date())!),
    Package(name: "Premium Health Package", benefits: ["4 Doctor Visits per 3 months", "2 Tests per month"], price: "$199", duration: "3 Months", startDate: Date(), endDate: Calendar.current.date(byAdding: .month, value: 3, to: Date())!),
    Package(name: "Family Health Package", benefits: ["6 Doctor Visits per 2 months", "3 Tests per month"], price: "$299", duration: "2 Months", startDate: Date(), endDate: Calendar.current.date(byAdding: .month, value: 2, to: Date())!),
    Package(name: "Comprehensive Health Package", benefits: ["Unlimited Doctor Visits", "Unlimited Tests"], price: "$499", duration: "1 Month", startDate: Date(), endDate: Calendar.current.date(byAdding: .month, value: 1, to: Date())!)
]

func formattedDate(_ date: Date) -> String {
    let formatter = DateFormatter()
    formatter.dateStyle = .medium
    return formatter.string(from: date)
}
