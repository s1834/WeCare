//
//  FamilyView.swift
//  WeCare
//
//  Created by s1834 on 18/02/25.
//

import SwiftUI
import UniformTypeIdentifiers

struct FamilyView: View {
    @State private var selectedTab = 0
    @State private var selectedPatient: String = ""
    @State private var isProfileSheetPresented = false
    @State private var appointmentDate: String = "No Appointment"
    let patients = ["John Doe", "Jane Smith", "Michael Brown"]
    
    var body: some View {
        NavigationView {
            ZStack {
                GradientBackground()
                
                VStack(spacing: 0) {
                    ScrollView {
                        VStack(spacing: 20) {
                            HStack {
                                VStack(alignment: .leading) {
                                    Text("WeCare")
                                        .font(.system(size: 44, weight: .bold, design: .rounded))
                                        .foregroundStyle(
                                            LinearGradient(
                                                gradient: Gradient(colors: [.blue, .green]),
                                                startPoint: .leading,
                                                endPoint: .trailing
                                            )
                                        )
                                        .shadow(radius: 5)
                                }
                                Spacer()
                                Button(action: { isProfileSheetPresented.toggle() }) {
                                    Image(systemName: "person.circle.fill")
                                        .resizable()
                                        .frame(width: 40, height: 40)
                                        .foregroundColor(.black)
                                }
                            }
                            .padding()

                            Picker("", selection: $selectedPatient) {
                                Text("Select Patient").tag("")
                                ForEach(patients, id: \.self) { patient in
                                    Text(patient)
                                }
                            }
                            .pickerStyle(MenuPickerStyle())
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)

                            if selectedTab == 0 {
                                HomeView(selectedPatient: $selectedPatient, patients: patients)
                            } else if selectedTab == 1 {
                                BookingOptionsView(selectedPatient: $selectedPatient, appointmentDate: $appointmentDate)
                            } else {
                                PackagesView(selectedPatient: $selectedPatient)
                            }

                            Spacer(minLength: 10)
                        }
                        .padding(.bottom, 80)
                    }

                    HStack {
                        TabBarItem(title: "Home", icon: "house", selectedTab: $selectedTab, index: 0)
                        TabBarItem(title: "Book", icon: "calendar.badge.plus", selectedTab: $selectedTab, index: 1)
                        TabBarItem(title: "Packages", icon: "gift", selectedTab: $selectedTab, index: 2)
                    }
                    .frame(height: 60)
                    .frame(maxWidth: .infinity)
                    .background(Color.white.opacity(0.9))
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .shadow(radius: 5)
                    .padding(.horizontal, 20)
                }
            }
            .sheet(isPresented: $isProfileSheetPresented) {
                FamilyProfileSheetView()
            }
            .navigationBarBackButtonHidden(true)
            .onAppear {
                if let savedDate = UserDefaults.standard.string(forKey: "\(selectedPatient)_nextAppointment") {
                    appointmentDate = savedDate
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}
