//
//  FamilyProfileSheetView.swift
//  WeCare
//
//  Created by s1834 on 20/02/25.
//

import SwiftUI

struct FamilyProfileSheetView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var firstName: String = "Meredith"
    @State private var lastName: String = "Grey"
    @State private var isLoggedOut = false
    @State private var showPatientDetails = false

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button(action: { presentationMode.wrappedValue.dismiss() }) {
                    HStack {
                        Image(systemName: "chevron.left")
                        Text("Back")
                    }
                    .foregroundColor(.blue)
                }
                Spacer()
                Text("Family Profile")
                    .font(.headline)
                    .bold()
                Spacer()
                Button("Done") { presentationMode.wrappedValue.dismiss() }
                    .foregroundColor(.blue)
            }
            .padding(.horizontal)
            .padding(.top, 20)

            Spacer()

            VStack(spacing: 10) {
                Image(systemName: "person.crop.circle.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 90, height: 90)
                    .foregroundColor(.gray)
                    .clipShape(Circle())
                    .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 2)

                Text("\(firstName) \(lastName)")
                    .font(.title2)
                    .fontWeight(.bold)
            }

            Spacer()

            VStack(spacing: 0) {
                EditableRow(label: "First Name", value: $firstName)
                Divider()
                EditableRow(label: "Last Name", value: $lastName)
                Divider()
            }
            .background(Color.white)
            .cornerRadius(12)
            .padding(.horizontal)

            Button(action: {
                showPatientDetails.toggle()
            }) {
                Text("View Patient Details")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .font(.system(size: 18, weight: .bold))
            }
            .padding()
            .padding(.top, 10)
            .sheet(isPresented: $showPatientDetails) {
                PatientDetailsView(patients: getPatients())
            }

            Button(action: {
                logoutUser()
            }) {
                Text("Logout")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.red.opacity(0.9))
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .font(.system(size: 18, weight: .bold))
            }
            .padding()
            .padding(.top, 10)
        }
        .background(Color.white.edgesIgnoringSafeArea(.all))
        .padding(.bottom)
        .fullScreenCover(isPresented: $isLoggedOut) {
            LoginView()
        }
    }

    func logoutUser() {
        UserDefaults.standard.removeObject(forKey: "currentUser")
        isLoggedOut = true
    }
    
    func getPatients() -> [Patient] {
        return [
            Patient(name: "John Doe"),
            Patient(name: "Jane Smith"),
            Patient(name: "Michael Brown")
        ]
    }
}

struct Patient {
    var name: String
}

struct PatientDetailsView: View {
    var patients: [Patient]

    var body: some View {
        VStack {
            Text("Patient Details")
                .font(.title)
                .fontWeight(.bold)
                .padding()

            ForEach(patients, id: \.name) { patient in
                VStack(alignment: .leading) {
                    Text("Name: \(patient.name)")
                    Text("Last Checkup: \(Constants.getLastCheckupDate(for: patient.name))")
                    Divider()
                }
                .padding(.vertical, 5)
            }
            Spacer()
        }
        .padding()
    }
}
