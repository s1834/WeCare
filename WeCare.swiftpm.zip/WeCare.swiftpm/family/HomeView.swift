//
//  HomeView.swift
//  WeCare
//
//  Created by s1834 on 20/02/25.
//

import SwiftUI

struct HomeView: View {
    @Binding var selectedPatient: String
    let patients: [String]
    
    @State private var uploadedReports: [String: [URL]] = [:]
    @State private var showReportSheet = false
    @State private var pdfURL: URL?
    @State private var showPDFViewer = false

    var body: some View {
        VStack {
            if !selectedPatient.isEmpty {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Last Checkup: \(Constants.getLastCheckupDate(for: selectedPatient))")
                        .font(.headline)
                        .foregroundColor(.black)

                    let nextAppointmentDate = DataStorage.getNextAppointmentDate(for: selectedPatient)
                    Text("Next Appointment: \(nextAppointmentDate != nil ? formatDate(nextAppointmentDate!) : "No upcoming appointment")")
                        .font(.headline)
                        .foregroundColor(.black)
                    
                    Button(action: {
                        fetchReports(for: selectedPatient)
                        showReportSheet.toggle()
                    }) {
                        Text("View Past Reports")
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                    }
                    .sheet(isPresented: $showReportSheet) {
                        if let reports = uploadedReports[selectedPatient], !reports.isEmpty {
                            ReportListView(
                                patient: selectedPatient,
                                uploadedReports: uploadedReports,
                                pdfURL: $pdfURL,
                                showPDFViewer: $showPDFViewer
                            )
                        } else {
                            Text("No reports available for \(selectedPatient)")
                        }
                    }
                }
                .padding()
            }
        }
    }

    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    private func fetchReports(for patient: String) {
        DispatchQueue.main.async {
            self.uploadedReports[patient] = DataStorage.fetchReports(for: patient)
            print("✅✅ Fetched \(self.uploadedReports[patient]?.count ?? 0) reports for \(patient)")
        }
    }
}
